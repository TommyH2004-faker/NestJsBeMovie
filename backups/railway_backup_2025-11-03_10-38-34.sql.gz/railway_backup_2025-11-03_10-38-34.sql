-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: caboose.proxy.rlwy.net    Database: railway
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `userId` int DEFAULT NULL,
  `movieId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_c0354a9a009d3bb45a08655ce3b` (`userId`),
  KEY `FK_aea4918c888422550a85e257894` (`movieId`),
  CONSTRAINT `FK_aea4918c888422550a85e257894` FOREIGN KEY (`movieId`) REFERENCES `movie` (`id`),
  CONSTRAINT `FK_c0354a9a009d3bb45a08655ce3b` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (55,'sdvdv','2025-09-08 21:34:59.862526',1,3),(56,'dsfsf','2025-09-08 21:34:59.863400',1,4),(61,'svdbgdgdg','2025-10-21 15:18:07.034219',1,39),(62,'rtryrhrh','2025-10-21 15:19:32.115869',1,39),(63,'fsfsf','2025-10-21 15:21:15.138421',3,40),(64,'ssg','2025-10-21 15:21:17.248754',3,40);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `episode`
--

DROP TABLE IF EXISTS `episode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `episode` (
  `id` int NOT NULL AUTO_INCREMENT,
  `episode_number` int DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `subtitle_url` varchar(255) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `movieId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_e41b7c5d24abe1d1cf4739c720d` (`movieId`),
  CONSTRAINT `FK_e41b7c5d24abe1d1cf4739c720d` FOREIGN KEY (`movieId`) REFERENCES `movie` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `episode`
--

LOCK TABLES `episode` WRITE;
/*!40000 ALTER TABLE `episode` DISABLE KEYS */;
INSERT INTO `episode` VALUES (2,1,'Episode 1','https://www.youtube.com/embed/JfVOs4VSpmA',NULL,'2025-08-05 09:06:09.000000',2),(3,1,'Episode 1','https://www.youtube.com/embed/qSqVVswa420',NULL,'2025-08-05 09:06:09.000000',3),(4,1,'Episode 1','https://www.youtube.com/embed/d9MyW72ELq0',NULL,'2025-08-05 09:06:09.000000',4),(5,1,'Episode 1','https://www.youtube.com/embed/_Z3QKkl1WyM',NULL,'2025-08-05 09:06:09.000000',5),(6,1,'Episode 1','https://www.youtube.com/embed/mqqft2x_Aa4',NULL,'2025-08-05 09:06:09.000000',6),(7,1,'Episode 1','https://www.youtube.com/embed/aWzlQ2N6qqg',NULL,'2025-08-05 09:06:09.000000',7),(8,1,'Episode 1','https://www.youtube.com/embed/Go8nTmfrQd8',NULL,'2025-08-05 09:06:09.000000',8),(9,1,'Episode 1','https://www.youtube.com/embed/T9VIUXcVwDs',NULL,'2025-08-05 09:06:09.000000',9),(10,1,'Episode 1','https://www.youtube.com/embed/fb5ELWi-ekk',NULL,'2025-08-05 09:06:09.000000',10),(21,2,'Episode 1: The tran hiep ','https://www.youtube.com/embed/TcMBFSGVi1c','https://example.com/subtitle/episode1.vtt','2025-08-05 21:31:35.480091',1),(22,3,'Episode 1: The rỷhfhBeginning','https://www.youtube.com/embed/h74AXqw4Opc','https://example.com/subtitle/episode1.vtt','2025-08-05 21:31:39.344510',1),(23,4,'Episode 1: The rỷhfhBeginning','https://www.youtube.com/embed/TcMBFSGVi1c','https://example.com/subtitle/episode1.vtt','2025-08-05 21:31:42.949212',1),(24,1,'Episode 1: Fast X','https://www.youtube.com/embed/32RAq6JzY-w',NULL,'2025-08-10 21:30:24.066701',11),(25,1,'Episode 1: John Wick: Chapter 4','https://www.youtube.com/embed/qEVUtrk8_B4',NULL,'2025-08-10 21:30:24.066701',12),(26,1,'Episode 1: The Super Mario Bros. Movie','https://www.youtube.com/embed/TnGl01FkMMo',NULL,'2025-08-10 21:30:24.066701',13),(27,1,'Episode 1: Scream VI','https://www.youtube.com/embed/h74AXqw4Opc',NULL,'2025-08-10 21:30:24.066701',14),(28,1,'Episode 1: Guardians of the Galaxy Vol. 3','https://www.youtube.com/embed/u3V5KDHRQvk',NULL,'2025-08-10 21:30:24.066701',15),(29,1,'Episode 1: Indiana Jones and the Dial of Destiny','https://www.youtube.com/embed/ZMysDhg2hLc',NULL,'2025-08-10 21:30:24.066701',16),(30,1,'Episode 1: Transformers: Rise of the Beasts','https://www.youtube.com/embed/itnqEauWQZM',NULL,'2025-08-10 21:30:24.066701',17),(31,1,'Episode 1: Spider-Man: Across the Spider-Verse','https://www.youtube.com/embed/cqGjhVJWtEg',NULL,'2025-08-10 21:30:24.066701',18),(32,1,'Episode 1: The Flash','https://www.youtube.com/embed/hebWYacbdvc',NULL,'2025-08-10 21:30:24.066701',19),(33,1,'Episode 1: Oppenheimer','https://www.youtube.com/embed/uYPbbksJxIg',NULL,'2025-08-10 21:30:24.066701',20),(34,1,'Episode 1: Barbie','https://www.youtube.com/embed/pBk4NYhWNMM',NULL,'2025-08-10 21:30:24.066701',21),(35,1,'Episode 1: Mission: Impossible – Dead Reckoning Part One','https://www.youtube.com/embed/avz06PDqDbM',NULL,'2025-08-10 21:30:24.066701',22),(36,1,'Episode 1: Ant-Man and the Wasp: Quantumania','https://www.youtube.com/embed/ZlNFpri-Y40',NULL,'2025-08-10 21:30:24.066701',23),(37,1,'Episode 1: Creed III','https://www.youtube.com/embed/AHmCH7iB_IM',NULL,'2025-08-10 21:30:24.066701',25),(38,1,'Episode 1: Dungeons & Dragons: Honor Among Thieves','https://www.youtube.com/embed/IiMinixSXII',NULL,'2025-08-10 21:30:24.066701',26),(39,1,'Episode 1: Evil Dead Rise','https://www.youtube.com/embed/BuPPV7X2cks',NULL,'2025-08-10 21:30:24.066701',27),(40,1,'Episode 1: The Little Mermaid','https://www.youtube.com/embed/foyufD52aog',NULL,'2025-08-10 21:30:24.066701',29),(41,1,'Episode 1: Puss in Boots: The Last Wish','https://www.youtube.com/embed/tHb7WlgyaUc',NULL,'2025-08-10 21:30:24.066701',30),(42,1,'Episode 1: The Hunger Games: The Ballad of Songbirds & Snakes','https://www.youtube.com/embed/NxW_X4kzeus',NULL,'2025-08-10 21:30:24.066701',33),(43,1,'Episode 1: Killers of the Flower Moon','https://www.youtube.com/embed/EP34Yoxs3FQ',NULL,'2025-08-10 21:30:24.066701',34),(44,1,'Episode 1: Ant-Man and the Wasp: Quantumania','https://www.youtube.com/embed/ug7JuDFg9R0',NULL,'2025-08-12 21:36:19.000000',36),(45,1,'Episode 1: Creed III','https://www.youtube.com/embed/AHmCH7iB_IM',NULL,'2025-08-12 21:36:19.000000',37),(46,1,'Episode 1: Dungeons & Dragons: Honor Among Thieves','https://www.youtube.com/embed/IiMinixSXII',NULL,'2025-08-12 21:36:19.000000',38),(47,1,'Episode 1: Evil Dead Rise','https://www.youtube.com/embed/zMlBx9CWgdI',NULL,'2025-08-12 21:36:19.000000',39),(48,1,'Episode 1: The Little Mermaid','https://www.youtube.com/embed/kpGo2_d3oYE',NULL,'2025-08-12 21:36:19.000000',40),(49,1,'Episode 1: Puss in Boots: The Last Wish','https://www.youtube.com/embed/fmuQiOORysY',NULL,'2025-08-12 21:36:19.000000',41),(50,1,'Episode 1: The Hunger Games: The Ballad of Songbirds & Snakes','https://www.youtube.com/embed/ws1V6KEjmZM',NULL,'2025-08-12 21:36:19.000000',42);
/*!40000 ALTER TABLE `episode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorite`
--

DROP TABLE IF EXISTS `favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorite` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `userId` int DEFAULT NULL,
  `movieId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_83b775fdebbe24c29b2b5831f2d` (`userId`),
  KEY `FK_c2e2781471d2bcdea6c55845d11` (`movieId`),
  CONSTRAINT `FK_83b775fdebbe24c29b2b5831f2d` FOREIGN KEY (`userId`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_c2e2781471d2bcdea6c55845d11` FOREIGN KEY (`movieId`) REFERENCES `movie` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorite`
--

LOCK TABLES `favorite` WRITE;
/*!40000 ALTER TABLE `favorite` DISABLE KEYS */;
INSERT INTO `favorite` VALUES (138,'2025-09-08 16:00:47.074613',3,25),(156,'2025-10-21 15:20:44.091537',3,39),(157,'2025-10-21 15:20:44.886673',3,40),(158,'2025-10-22 14:32:21.103997',1,42),(160,'2025-11-02 13:42:06.405781',1,39),(161,'2025-11-02 13:42:07.638747',1,40),(162,'2025-11-02 13:42:08.068575',1,41);
/*!40000 ALTER TABLE `favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genre`
--

DROP TABLE IF EXISTS `genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genre` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_dd8cd9e50dd049656e4be1f7e8` (`name`),
  UNIQUE KEY `IDX_8fc42c0cf741b5006b5ffd12f2` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genre`
--

LOCK TABLES `genre` WRITE;
/*!40000 ALTER TABLE `genre` DISABLE KEYS */;
INSERT INTO `genre` VALUES (2,'Phim Chiếu Rạp','phim-chieu-rap','2025-08-12 21:19:07.970312','2025-08-12 21:19:07.970312'),(3,'Phim Trọn Bộ','phim-tron-bo','2025-08-12 21:19:07.971546','2025-08-12 21:19:07.971546'),(4,'Phim Bộ','phim-bo','2025-08-12 21:19:07.973053','2025-08-12 21:19:07.973053'),(15,'Khoa học viễn tưởng','khoa-hoc-vien-tuong','2025-08-08 08:45:35.880693','2025-08-08 08:45:36.008728'),(17,'Tâm lý','tam-ly','2025-08-08 08:45:35.880693','2025-08-08 08:45:36.008728'),(18,'Siêu anh hùng','sieu-anh-hung','2025-08-08 08:45:35.880693','2025-08-08 08:45:36.008728'),(20,'Kinh dị','kinh-di','2025-08-08 08:45:35.880693','2025-08-08 08:45:36.008728'),(21,'Lãng mạn','lang-man','2025-08-08 08:45:35.880693','2025-08-08 08:45:36.008728'),(24,'Phim Mới','phim-moi','2025-08-08 08:45:35.880693','2025-08-18 21:21:32.315979'),(29,'Phim Lẻ','phim-le','2025-09-04 22:19:38.619765','2025-09-04 22:19:38.619765');
/*!40000 ALTER TABLE `genre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie`
--

DROP TABLE IF EXISTS `movie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movie` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `duration` int DEFAULT NULL,
  `poster_url` varchar(255) NOT NULL,
  `banner_url` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'ongoing',
  `views` int NOT NULL DEFAULT '0',
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `original_title` varchar(255) DEFAULT NULL,
  `trailer_url` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `director` varchar(255) DEFAULT NULL,
  `cast` text,
  `rating` decimal(3,1) DEFAULT NULL,
  `release_date` year DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_454288774942b99d5127fb4173` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES (1,'Avengers: Endgame','the-great-adventure','Sau những sự kiện tàn khốc của Infinity War, vũ trụ đang trong tình trạng hỗn loạn. Với sự giúp đỡ của các đồng minh còn lại, các Avengers phải tập hợp một lần nữa để đảo ngược hành động của Thanos và khôi phục lại trật tự vũ trụ.',120,'https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/7RyHsO4yDXtBv1zUU3mTpHeQ0d5.jpg','ongoing',102,'2025-08-05 09:06:09.000000','2025-10-23 20:14:18.000000','Avengers: Endgame','https://www.youtube.com/watch?v=TcMBFSGVi1c','movie','USA','Anthony & Joe Russo','Robert Downey Jr., Chris Evans, Mark Ruffalo, Chris Hemsworth, Scarlett Johansson, Jeremy Renner',4.0,2016),(2,'Spider-Man: No Way Home','romantic-escape','Lần đầu tiên trong lịch sử điện ảnh của Spider-Man, danh tính của người nhện thân thiện đã bị tiết lộ, khiến Peter Parker không còn có thể tách biệt cuộc sống bình thường với việc làm siêu anh hùng đầy trách nhiệm.',110,'https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/14QbnygCuTO0vl7CAFmPf1fgZfV.jpg','completed',208,'2025-08-05 09:06:09.000000','2025-09-08 20:32:26.000000','Spider-Man: No Way Home','https://www.youtube.com/watch?v=JfVOs4VSpmA','movie','USA','Jon Watts','Tom Holland, Zendaya, Benedict Cumberbatch, Jacob Batalon, Jon Favreau, Marisa Tomei',5.0,2026),(3,'Top Gun: Maverick','horror-night','Sau hơn ba thập kỷ phục vụ như một trong những phi công hàng đầu của Hải quân, Pete \"Maverick\" Mitchell đang ở nơi anh thuộc về, vượt qua giới hạn như một phi công thử nghiệm dũng cảm và né tránh sự thăng tiến có thể khiến anh phải nghỉ hưu.',100,'https://image.tmdb.org/t/p/w500/62HCnUTziyWcpDaBO2i1DX17ljH.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/odJ4hx6g6vBt4lBWKFD1tI8WS4x.jpg','ongoing',154,'2025-08-05 09:06:09.000000','2025-09-08 16:02:00.000000','Top Gun: Maverick','https://www.youtube.com/watch?v=qSqVVswa420','movie','USA','Joseph Kosinski','Tom Cruise, Miles Teller, Jennifer Connelly, Jon Hamm, Glen Powell, Lewis Pullman',3.0,2020),(4,'Avatar: The Way of Water','future-tech','Bộ phim kể về câu chuyện của gia đình Sully (Jake, Neytiri và các con của họ), những rắc rối theo đuổi họ, những gì họ phải làm để giữ an toàn cho nhau, các cuộc chiến họ phải chiến đấu để sống sót, và những bi kịch họ phải chịu đựng.',130,'https://image.tmdb.org/t/p/w500/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/s16H6tpK2utvwDtzZ8Qy4qm5Emw.jpg','ongoing',254,'2025-08-05 09:06:09.000000','2025-09-05 22:09:04.000000','Avatar: The Way of Water','https://www.youtube.com/watch?v=d9MyW72ELq0','movie','USA','James Cameron','Sam Worthington, Zoe Saldana, Sigourney Weaver, Stephen Lang, Kate Winslet',3.5,2024),(5,'Black Panther: Wakanda Forever','comedy-club','Nữ hoàng Ramonda, Shuri, M\'Baku, Okoye và Dora Milaje chiến đấu để bảo vệ quốc gia họ khỏi các thế lực can thiệp sau cái chết của Vua T\'Challa. Khi người Wakanda cố gắng nắm bắt chương tiếp theo của họ, các anh hùng phải đoàn kết với sự giúp đỡ của War Dog Nakia và Everett Ross.',90,'https://image.tmdb.org/t/p/w500/sv1xJUazXeYqALzczSZ3O6nkH75.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/yYrvN5WFeGYjJnRzhY0QXuo4Isw.jpg','completed',300,'2025-08-05 09:06:09.000000','2025-08-10 15:00:13.449783','Black Panther: Wakanda Forever','https://www.youtube.com/watch?v=_Z3QKkl1WyM','movie','USA','Ryan Coogler','Letitia Wright, Angela Bassett, Tenoch Huerta, Danai Gurira, Winston Duke',4.0,2029),(6,'The Batman','fantasy-world','Khi kẻ giết người hàng loạt Riddler bắt đầu giết chóc những nhân vật chủ chốt ở Gotham, Batman phải điều tra tham nhũng của thành phố và đặt câu hỏi về sự liên quan của gia đình mình.',140,'https://image.tmdb.org/t/p/w500/b0PlSFdDwbyK0cf5RxwDpaOJQvQ.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/nb3xI8XI3w4pMVZ38VijbsyBqP4.jpg','ongoing',184,'2025-08-05 09:06:09.000000','2025-11-02 13:31:16.000000','The Batman','https://www.youtube.com/watch?v=mqqft2x_Aa4','movie','USA','Matt Reeves','Robert Pattinson, Zoë Kravitz, Paul Dano, Jeffrey Wright, Colin Farrell',4.5,2024),(7,'Doctor Strange in the Multiverse of Madness','thrill-ride','Doctor Strange, với sự giúp đỡ của các đồng minh thần bí cả cũ và mới, đi khắp những thực tại thay đổi và nguy hiểm của Đa vũ trụ để đối mặt với một kẻ thù bí ẩn mới.',150,'https://image.tmdb.org/t/p/w500/9Gtg2DzBhmYamXBS1hKAhiwbBKS.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/wcKFYIiVDvRURrzglV9kGu7fpfY.jpg','ongoing',220,'2025-08-05 09:06:09.000000','2025-11-02 13:34:41.030000','Doctor Strange in the Multiverse of Madness','https://www.youtube.com/watch?v=aWzlQ2N6qqg','movie','USA','Sam Raimi','Benedict Cumberbatch, Elizabeth Olsen, Chiwetel Ejiofor, Benedict Wong, Xochitl Gomez',4.0,2021),(8,'Thor: Love and Thunder','life-documentary','Thor bắt đầu một hành trình không giống bất kỳ điều gì anh từng đối mặt - một nhiệm vụ tìm kiếm sự bình yên nội tâm. Nhưng việc nghỉ hưu của Thor bị gián đoạn bởi một kẻ giết người thiên hà được biết đến với cái tên Gorr the God Butcher.',160,'https://image.tmdb.org/t/p/w500/pIkRyD18kl4FhoCNQuWxWu5cBLM.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/p1F51Lvj3sMopG948F5HsBbl43C.jpg','completed',190,'2025-08-05 09:06:09.000000','2025-08-10 15:00:13.449783','Thor: Love and Thunder','https://www.youtube.com/watch?v=Go8nTmfrQd8','movie','USA','Taika Waititi','Chris Hemsworth, Christian Bale, Tessa Thompson, Jaimie Alexander, Taika Waititi',4.0,2016),(9,'Minions: The Rise of Gru','sci-fi-odyssey','Năm 1970, trong thời kỳ hoàng kim của funk, Gru đang lớn lên ở vùng ngoại ô và là một fan hâm mộ lớn của một nhóm siêu ác nhân được biết đến với cái tên Vicious 6.',170,'https://image.tmdb.org/t/p/w500/wKiOkZTN9lUUUNZLmtnwubZYONg.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/uoT3MmdlhZWrbzJqK7Aaw8Q0cNp.jpg','ongoing',400,'2025-08-05 09:06:09.000000','2025-08-10 15:00:13.449783','Minions: The Rise of Gru','https://www.youtube.com/watch?v=T9VIUXcVwDs','animation','USA','Kyle Balda','Steve Carell, Pierre Coffin, Alan Arkin, Taraji P. Henson, Michelle Yeoh',3.5,2020),(10,'Jurassic World Dominion','epic-drama','Bốn năm sau khi Isla Nublar bị phá hủy, khủng long hiện đang sống và săn mồi cùng với con người trên khắp thế giới. Sự cân bằng mong manh này sẽ định hình lại tương lai và xác định, một lần và mãi mãi, liệu con người có tiếp tục là những kẻ săn mồi hàng đầu trên hành tinh mà họ giờ chia sẻ với những sinh vật đáng sợ nhất trong lịch sử.',180,'https://image.tmdb.org/t/p/w500/kAVRgw7GgK1CfYEJq8ME6EvRIgU.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/9485L4kNllXCvEQOCBJQvdIKv4N.jpg','ongoing',350,'2025-08-05 09:06:09.000000','2025-08-10 15:00:13.449783','Jurassic World Dominion','https://www.youtube.com/watch?v=fb5ELWi-ekk','movie','USA','Colin Trevorrow','Chris Pratt, Bryce Dallas Howard, Laura Dern, Sam Neill, Jeff Goldblum',3.4,2020),(11,'Fast X','lost-in-the-jungle','Trong Fast X, Dom Toretto và gia đình của anh phải đối mặt với kẻ thù nguy hiểm nhất mà họ từng gặp: Một mối đe dọa khủng khiếp nổi lên từ bóng tối của quá khứ, được thúc đẩy bởi sự báo thù đẫm máu và quyết tâm phá vỡ gia đình này.',120,'https://image.tmdb.org/t/p/w500/fiVW06jE7z9YnO4trhaMEdclSiC.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/4XM8DUTQb3lhLemJC51Jx4a2EuA.jpg','ongoing',120,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Fast X','https://www.youtube.com/watch?v=32RAq6JzY-w','movie','USA','Louis Leterrier','Vin Diesel, Michelle Rodriguez, Tyrese Gibson, Chris Ludacris Bridges, John Cena',5.0,2026),(12,'John Wick: Chapter 4','love-in-paris','John Wick khám phá ra một con đường để đánh bại High Table. Nhưng trước khi anh có thể giành được tự do, Wick phải đối mặt với một kẻ thù mới với những liên minh mạnh mẽ trên khắp thế giới và những lực lượng biến những người bạn cũ thành kẻ thù.',115,'https://image.tmdb.org/t/p/w500/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/h7dZpJDORYs5c56dydbrLFkEXpE.jpg','completed',210,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','John Wick: Chapter 4','https://www.youtube.com/watch?v=qEVUtrk8_B4','movie','USA','Chad Stahelski','Keanu Reeves, Donnie Yen, Bill Skarsgård, Laurence Fishburne, Hiroyuki Sanada',3.0,2024),(13,'The Super Mario Bros. Movie','haunted-house','Bộ phim hoạt hình theo dõi Mario và Luigi, hai anh em thợ sửa ống nước, khi họ bị cuốn vào một cuộc phiêu lưu kỳ thú để cứu một công chúa bị bắt cóc.',105,'https://image.tmdb.org/t/p/w500/qNBAXBIQlnOThrVvA6mA2B5ggV6.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/9n2tJBplPbgR2ca05hS5CKXwP2c.jpg','ongoing',180,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','The Super Mario Bros. Movie','https://www.youtube.com/watch?v=TnGl01FkMMo','animation','USA','Aaron Horvath & Michael Jelenic','Chris Pratt, Anya Taylor-Joy, Charlie Day, Jack Black, Keegan-Michael Key',4.0,2026),(14,'Scream VI','space-odyssey','Sau các vụ giết người gần đây, các chị em Carpenter rời Woodsboro để bắt đầu một chương mới. Ở New York, họ lại một lần nữa phải đối mặt với quá khứ khi một kẻ giết người mới bắt đầu một chuỗi giết chóc đẫm máu.',140,'https://image.tmdb.org/t/p/w500/wDWwtvkRRlgTiUr6TyLSMX8FCuZ.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/a8tQ4DNSjhTci9LDNtddbKzXTaX.jpg','ongoing',300,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Scream VI','https://www.youtube.com/watch?v=h74AXqw4Opc','movie','USA','Matt Bettinelli-Olpin & Tyler Gillett','Melissa Barrera, Jenna Ortega, Jasmin Savoy Brown, Mason Gooding, Courteney Cox',4.0,2030),(15,'Guardians of the Galaxy Vol. 3','stand-up-comedy-night','Peter Quill, vẫn đang chấn động vì việc mất đi Gamora, phải tập hợp đội của mình xung quanh để bảo vệ vũ trụ cùng với việc bảo vệ một trong số họ - một nhiệm vụ có thể có nghĩa là kết thúc của Guardians nếu không thành công.',90,'https://image.tmdb.org/t/p/w500/r2J02Z2OpNTctfOSN1Ydgii51I3.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/5YZbUmjbMa3ClvSW1Wj3Ga9fZLn.jpg','completed',270,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Guardians of the Galaxy Vol. 3','https://www.youtube.com/watch?v=u3V5KDHRQvk','movie','USA','James Gunn','Chris Pratt, Zoe Saldana, Dave Bautista, Karen Gillan, Pom Klementieff',4.0,2026),(16,'Indiana Jones and the Dial of Destiny','legend-of-the-dragon','Nhà khảo cổ học huyền thoại Indiana Jones sắp nghỉ hưu khi anh thấy mình trong một thế giới dường như đã vượt qua anh. Đối mặt với việc trở lại một người quen cũ, Indy phải đội chiếc mũ fedora một lần cuối cùng để hoàn thành một nhiệm vụ cuối cùng.',145,'https://image.tmdb.org/t/p/w500/Af4bXE63pVsb2FtbW8uYIyPBadD.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/1HdUABPWbh8A20vHAicSJOLQkzr.jpg','ongoing',230,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Indiana Jones and the Dial of Destiny','https://www.youtube.com/watch?v=ZMysDhg2hLc','movie','USA','James Mangold','Harrison Ford, Phoebe Waller-Bridge, Antonio Banderas, John Rhys-Davies, Shaunette Renée Wilson',3.0,2024),(17,'Transformers: Rise of the Beasts','edge-of-tomorrow','Quay trở lại hành động và phiêu lưu của Transformers, bộ phim sẽ đưa khán giả vào một cuộc phiêu lưu toàn cầu thập niên 90 và giới thiệu Maximals, Predacons và Terrorcons.',135,'https://image.tmdb.org/t/p/w500/gPbM0MK8CP8A174rmUwGsADNYKD.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/bz66a19bR6BKsbY8gSZCM4etJiK.jpg','ongoing',400,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Transformers: Rise of the Beasts','https://www.youtube.com/watch?v=itnqEauWQZM','movie','USA','Steven Caple Jr.','Anthony Ramos, Dominique Fishback, Luna Lauren Velez, Dean Scott Vazquez',3.0,2026),(18,'Spider-Man: Across the Spider-Verse','secrets-of-the-ocean','Miles Morales tái xuất trong Spider-Verse tiếp theo, một cuộc phiêu lưu hoành tráng sẽ đưa Spider-Man thân thiện của Brooklyn qua Đa vũ trụ để hợp tác với Gwen Stacy và một đội ngũ Spider-People mới.',160,'https://image.tmdb.org/t/p/w500/8Vt6mWEReuy4Of61Lnj5Xj704m8.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/nGxUxi3PfXDRm7Vg95VBNgNM8yc.jpg','completed',220,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Spider-Man: Across the Spider-Verse','https://www.youtube.com/watch?v=cqGjhVJWtEg','animation','USA','Joaquim Dos Santos & Kemp Powers','Shameik Moore, Hailee Steinfeld, Brian Tyree Henry, Luna Lauren Velez, Jake Johnson',3.0,2030),(19,'The Flash','the-last-kingdom','Barry sử dụng siêu tốc độ của mình để du hành ngược thời gian nhằm thay đổi các sự kiện trong quá khứ. Nhưng khi nỗ lực cứu gia đình của mình vô tình thay đổi tương lai, Barry bị kẹt trong một thực tại mà General Zod đã trở lại.',175,'https://image.tmdb.org/t/p/w500/rktDFPbfHfUbArZ6OOOKsXcv0Bm.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/yF1eOkaYvwiORauRCPWznV9xVvi.jpg','ongoing',350,'2025-08-05 09:10:16.000000','2025-11-02 13:36:58.584000','The Flash','https://www.youtube.com/watch?v=hebWYacbdvc','movie','USA','Andy Muschietti','Ezra Miller, Sasha Calle, Michael Shannon, Ron Livingston, Maribel Verdú',3.0,2024),(20,'Oppenheimer','mystery-in-the-woods','Câu chuyện về nhà vật lý lý thuyết người Mỹ J. Robert Oppenheimer, người đứng đầu phòng thí nghiệm Los Alamos trong Thế chiến II, và vai trò của ông trong việc phát triển bom nguyên tử.',125,'https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/rLb2cwF3Pazuxaj0sRXQ037tGI1.jpg','ongoing',190,'2025-08-05 09:10:16.000000','2025-11-02 13:36:45.395000','Oppenheimer','https://www.youtube.com/watch?v=uYPbbksJxIg','movie','USA','Christopher Nolan','Cillian Murphy, Emily Blunt, Matt Damon, Robert Downey Jr., Florence Pugh',2.0,2015),(21,'Barbie','underworld-rising','Barbie và Ken đang có một ngày tuyệt vời trong thế giới đầy màu sắc và dường như hoàn hảo của Barbie Land. Tuy nhiên, khi họ có cơ hội đi đến thế giới thực, họ sớm khám phá ra niềm vui và nguy hiểm của việc sống giữa những con người.',150,'https://image.tmdb.org/t/p/w500/iuFNMS8U5cb6xfzi51Dbkovj7vM.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/ctmxGCy4pDNFEZdWXZBL4DwU5hm.jpg','ongoing',280,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Barbie','https://www.youtube.com/watch?v=pBk4NYhWNMM','movie','USA','Greta Gerwig','Margot Robbie, Ryan Gosling, America Ferrera, Kate McKinnon, Issa Rae',1.0,2022),(22,'Mission: Impossible – Dead Reckoning Part One','tears-of-the-moon','Ethan Hunt và nhóm IMF của anh ấy bắt tay vào nhiệm vụ nguy hiểm nhất của họ: Truy tìm một vũ khí mới đáng sợ đe dọa toàn nhân loại trước khi nó rơi vào tay kẻ xấu.',135,'https://image.tmdb.org/t/p/w500/NNxYkU70HPurnNCSiCjYAmacwm.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/628Dep6AxEtDxjZoGP78TsOxYbK.jpg','completed',260,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Mission: Impossible – Dead Reckoning Part One','https://www.youtube.com/watch?v=avz06PDqDbM','movie','USA','Christopher McQuarrie','Tom Cruise, Hayley Atwell, Ving Rhames, Simon Pegg, Rebecca Ferguson',5.0,2016),(23,'Ant-Man and the Wasp: Quantumania','cyber-city-2099','Scott Lang và Hope Van Dyne cùng với Hank Pym và Janet Van Dyne khám phá Quantum Realm, nơi họ tương tác với những sinh vật kỳ lạ và bắt đầu một cuộc phiêu lưu vượt qua giới hạn của những gì họ nghĩ là có thể.',155,'https://image.tmdb.org/t/p/w500/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/1Rr5SrvHxMXHu5RjKpaMba8VTzi.jpg','ongoing',310,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Ant-Man and the Wasp: Quantumania','https://www.youtube.com/watch?v=ZlNFpri-Y40','movie','USA','Peyton Reed','Paul Rudd, Evangeline Lilly, Michael Douglas, Michelle Pfeiffer, Jonathan Majors',4.2,2016),(25,'Creed III','voices-from-beyond','Sau khi thống trị thế giới quyền anh, Adonis Creed đã phát triển mạnh mẽ cả trong sự nghiệp lẫn cuộc sống gia đình. Khi một người bạn thời thơ ấu và cựu vô địch quyền anh thần đồng Damian Anderson tái xuất sau khi ra tù dài hạn, anh ta háo hức chứng minh rằng mình xứng đáng được trở lại võ đài.',120,'https://image.tmdb.org/t/p/w500/cvsXj3I9Q2iyyIo95AecSd1tad7.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/tTnGO1W9P8m6DKPB6o1r8L0cLOL.jpg','ongoing',210,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Creed III','https://www.youtube.com/watch?v=AHmCH7iB_IM','movie','USA','Michael B. Jordan','Michael B. Jordan, Tessa Thompson, Jonathan Majors, Wood Harris, Mila Davis-Kent',3.0,2018),(26,'Dungeons & Dragons: Honor Among Thieves','dance-of-flames','Một tên trộm quyến rũ và một nhóm những kẻ phiêu lưu khó có thể xảy ra bắt tay vào một vụ trộm hoành tráng để lấy lại một di vật bị mất, nhưng mọi thứ trở nên nguy hiểm một cách khủng khiếp khi họ chạy trúng những người sai.',130,'https://image.tmdb.org/t/p/w500/A7AoNT06aRAc4SV89Dwxj3EYAgC.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/v28T5F1IygM8vXWZIycfNEm3xcL.jpg','ongoing',230,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Dungeons & Dragons: Honor Among Thieves','https://www.youtube.com/watch?v=IiMinixSXII','movie','USA','Jonathan Goldstein & John Francis Daley','Chris Pine, Michelle Rodriguez, Regé-Jean Page, Justice Smith, Sophia Lillis',4.0,2029),(27,'Evil Dead Rise','shadow-warriors','Một câu chuyện xoay quanh hai chị em xa cách, cuộc đoàn tụ của họ bị cắt ngắn bởi sự trỗi dậy của những con quỷ sở hữu thịt, đẩy họ vào một cuộc chiến sinh tồn nguyên thủy khi họ phải đối mặt với phiên bản ác mộng nhất của gia đình.',160,'https://image.tmdb.org/t/p/w500/5ik4ATKmNtmJU6AYD0bLm56BCVM.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/56RHPyK5uZhK3jJwNRrZ4sRrQ7T.jpg','ongoing',400,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','Evil Dead Rise','https://www.youtube.com/watch?v=BuPPV7X2cks','movie','New Zealand','Lee Cronin','Alyssa Sutherland, Lily Sullivan, Gabrielle Echols, Morgan Davies, Nell Fisher',4.0,2026),(29,'The Little Mermaid','echoes-of-the-past','Phiên bản live-action của câu chuyện cổ tích Disney yêu thích kể về nàng tiên cá Ariel, một nàng tiên cá trẻ tuổi tràn đầy tò mò và gan dạ, con gái của Vua Triton và cô em gái thích phiêu lưu nhất trong số các chị em.',145,'https://image.tmdb.org/t/p/w500/ym1dxyOk4jFcSl4Q2zmRrA5BEEN.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/7ZP8HtgOIDaBs12krXgUIygqEsy.jpg','ongoing',250,'2025-08-05 09:10:16.000000','2025-08-10 15:00:13.449783','The Little Mermaid','https://www.youtube.com/watch?v=foyufD52aog','movie','USA','Rob Marshall','Halle Bailey, Jonah Hauer-King, Daveed Diggs, Awkwafina, Jacob Tremblay',3.0,2028),(30,'Puss in Boots: The Last Wish','rise-of-the-phoenix','Puss in Boots khám phá ra rằng niềm đam mê phiêu lưu của anh đã có cái giá: anh đã đốt cháy tám trong số chín mạng sống của mình, khiến Puss mất đi khả năng bất tử. Với chỉ một mạng sống còn lại, Puss phải khiêm tốn yêu cầu sự giúp đỡ từ người bạn đồng hành cũ Kitty Paws.',155,'https://image.tmdb.org/t/p/w500/kuf6dutpsT0vSVehic3EZIqkOBt.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/r9PkFnRUIthgBp2JZZzD380MWZy.jpg','ongoing',422,'2025-08-05 09:10:16.000000','2025-11-02 13:36:35.043000','Puss in Boots: The Last Wish','https://www.youtube.com/watch?v=tHb7WlgyaUc','movie','USA','Joel Crawford','Antonio Banderas, Salma Hayek, Harvey Guillén, Florence Pugh, Olivia Colman',2.0,2018),(33,'The Hunger Games: The Ballad of Songbirds & Snakes','mystegsgsry-ins-the-woods','Trở lại với thế giới của Panem 64 năm trước các sự kiện trong The Hunger Games, bộ phim theo dõi Coriolanus Snow 18 tuổi khi anh được chọn làm mentor cho các tribute từ District 12.',125,'https://image.tmdb.org/t/p/w500/mBaXZ95R2OxueZhvQbcEWy2DqyO.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/4fLZUr1e65hKPPVw0R3PmKFKxj1.jpg','ongoing',192,'2025-08-05 15:09:40.515814','2025-11-02 13:36:21.151000','The Hunger Games: The Ballad of Songbirds & Snakes','https://www.youtube.com/watch?v=NxW_X4kzeus','movie','USA','Francis Lawrence','Tom Blyth, Rachel Zegler, Viola Davis, Peter Dinklage, Hunter Schafer',1.0,2024),(34,'Killers of the Flower Moon','mystegsgsry-cvcins-the-woods','Khi dầu được phát hiện trong đất của quốc gia Osage vào thập niên 1920, người Osage trong Oklahoma trở nên vô cùng giàu có gần như qua đêm. Sự giàu có này thu hút sự chú ý của những kẻ bạc đãi trắng, dẫn đến cuộc điều tra FBI về loạt vụ giết người bí ẩn.',125,'https://image.tmdb.org/t/p/w500/dB6Krk806zeqd0YNp2ngQ9zXteH.jpg','https://image.tmdb.org/t/p/w1920_and_h800_multi_faces/7I6VUdPj6tQECNHdviJkUHD2u89.jpg','ongoing',192,'2025-08-05 15:10:34.278795','2025-11-02 13:35:10.352000','Killers of the Flower Moon','https://www.youtube.com/watch?v=EP34Yoxs3FQ','movie','USA','Martin Scorsese','Leonardo DiCaprio, Robert De Niro, Lily Gladstone, Jesse Plemons, Tantoo Cardinal',2.0,2019),(35,'Hành Trình Xuyên Không','hanh-trinh-xuyen-khong','Một nhà khoa học vô tình xuyên không về quá khứ.',120,'https://m.media-amazon.com/images/I/71niXI3lxlL._AC_SL1024_.jpg','https://m.media-amazon.com/images/I/81O1oy0mNAL._AC_SL1500_.jpg','completed',1500,'2025-08-12 21:25:56.000000','2025-11-02 13:36:10.812000','Time Travel Adventure','https://www.youtube.com/embed/abcd1234','movie','Việt Nam','Nguyễn Văn A','Diễn viên A, Diễn viên B',3.0,2024),(36,'Kẻ Truy Sát Bí Ẩn','ke-truy-sat-bi-an','Một sát thủ phải đối đầu với quá khứ của chính mình.',110,'https://m.media-amazon.com/images/I/71niXI3lxlL._AC_SL1024_.jpg','https://m.media-amazon.com/images/I/81O1oy0mNAL._AC_SL1500_.jpg','completed',2116,'2025-08-12 21:25:56.000000','2025-09-08 20:59:40.000000','The Silent Hunter','https://www.youtube.com/embed/efgh5678','movie','Mỹ','John Smith','Actor X, Actor Y',2.0,2023),(37,'Cuộc Chiến Vũ Trụ','cuoc-chien-vu-tru','Cuộc chiến sinh tồn giữa các hành tinh.',145,'https://m.media-amazon.com/images/I/71c05lTE03L._AC_SL1024_.jpg','https://m.media-amazon.com/images/I/81FGr2z3f-L._AC_SL1500_.jpg','completed',5000,'2025-08-12 21:25:56.000000','2025-11-02 13:34:55.493000','Galaxy War','https://www.youtube.com/embed/hijk9012','movie','Hàn Quốc','Park Chan-wook','Actor K, Actor L',3.0,2025),(38,'Thành Phố Ngầm','thanh-pho-ngam','Một nhóm người tìm cách thoát khỏi thành phố bị bỏ hoang.',130,'https://image.tmdb.org/t/p/w500/kyeqWdyUXW608qlYkRqosgbbJyK.jpg','https://image.tmdb.org/t/p/original/1yIXO2ey4XyXcdR7k19MuMSqOQE.jpg','completed',4300,'2025-08-12 21:25:56.000000','2025-11-02 13:36:01.467000','Underground City','https://www.youtube.com/embed/lmno3456','movie','Nhật Bản','Hayao Miyazaki','Actor M, Actor N',2.5,2024),(39,'Tình Yêu Vượt Thời Gian','tinh-yeu-vuot-thoi-gian','Chuyện tình lãng mạn kéo dài hàng thế kỷ.',90,'https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg','https://image.tmdb.org/t/p/original/ulzhLuWrPK07P1YkdWQLZnQh1JL.jpg','completed',7212,'2025-08-12 21:25:56.000000','2025-11-02 13:35:50.391000','Love Beyond Time','https://www.youtube.com/embed/pqrs7890','series','Việt Nam','Trần Văn B','Diễn viên C, Diễn viên D',3.5,2022),(40,'Vùng Đất Huyền Bí','vung-dat-huyen-bi','Những chiến binh bảo vệ vùng đất cổ xưa.',89,'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg','https://image.tmdb.org/t/p/original/hZkgoQYus5vegHoetLkCJzb17zJ.jpg','completed',6924,'2025-08-12 21:25:56.000000','2025-11-02 13:35:41.850000','Mystic Land','https://www.youtube.com/embed/tuvw1234','series','Mỹ','James Cameron','Actor P, Actor Q',4.0,2021),(41,'Biệt Đội Siêu Anh Hùng','biet-doi-sieu-anh-hung','Biệt đội chống lại thế lực hắc ám.',110,'https://image.tmdb.org/t/p/w500/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg','https://image.tmdb.org/t/p/original/yDiT9n3KXJBGzLh4xN4Rk3vzxW3.jpg','ongoing',8018,'2025-08-12 21:25:56.000000','2025-11-02 13:35:32.197000','Superhero Squad','https://www.youtube.com/embed/xyza5678','series','Mỹ','Anthony Russo','Actor R, Actor S',5.0,2020),(42,'Học Viện Pháp Thuậtrry','hoc-vien-phap-thuat','Những học viên trẻ tuổi khám phá sức mạnh phép thuật.',100,'https://image.tmdb.org/t/p/w500/rhr4y79GpxQF9IsfJItRXVaoGs4.jpg','https://res.cloudinary.com/duhi7od89/image/upload/v1761227922/movies/images-1761227810688.jpg','ongoing',7535,'2025-08-12 21:25:56.000000','2025-11-02 08:38:13.000000','Magic Academy','https://www.youtube.com/embed/bcde9012','series','Anh','David Yates','Actor T, Actor U',4.0,2022);
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movie_genres`
--

DROP TABLE IF EXISTS `movie_genres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movie_genres` (
  `movie_id` int NOT NULL,
  `genre_id` int NOT NULL,
  PRIMARY KEY (`movie_id`,`genre_id`),
  KEY `IDX_ae967ce58ef99e9ff3933ccea4` (`movie_id`),
  KEY `IDX_bbbc12542564f7ff56e36f5bbf` (`genre_id`),
  CONSTRAINT `FK_ae967ce58ef99e9ff3933ccea48` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_bbbc12542564f7ff56e36f5bbf6` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movie_genres`
--

LOCK TABLES `movie_genres` WRITE;
/*!40000 ALTER TABLE `movie_genres` DISABLE KEYS */;
INSERT INTO `movie_genres` VALUES (1,24),(2,15),(2,24),(3,24),(4,17),(4,24),(5,18),(5,24),(6,24),(7,2),(7,3),(7,4),(7,15),(7,17),(7,18),(7,20),(7,21),(7,24),(7,29),(8,21),(11,24),(14,17),(15,18),(17,20),(18,21),(19,17),(19,18),(19,20),(20,20),(20,21),(20,24),(20,29),(21,24),(27,21),(30,2),(30,3),(30,4),(33,18),(33,21),(33,24),(33,29),(34,2),(34,3),(34,4),(34,15),(34,17),(34,18),(34,20),(34,21),(34,24),(34,29),(35,20),(35,21),(35,24),(35,29),(37,2),(37,3),(37,4),(37,15),(37,17),(37,18),(37,20),(37,21),(37,24),(37,29),(38,2),(38,3),(38,4),(38,17),(39,2),(39,3),(39,4),(40,2),(40,3),(40,4),(41,2),(41,3),(41,4),(41,15),(42,2),(42,3),(42,4),(42,15),(42,17);
/*!40000 ALTER TABLE `movie_genres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int NOT NULL,
  `description` text NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rating` int NOT NULL,
  `comment` text,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `userId` int DEFAULT NULL,
  `movieId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_4ccf71f9d14aa1a059877b06343` (`movieId`),
  KEY `FK_1337f93918c70837d3cea105d39` (`userId`),
  CONSTRAINT `FK_1337f93918c70837d3cea105d39` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_4ccf71f9d14aa1a059877b06343` FOREIGN KEY (`movieId`) REFERENCES `movie` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (2,5,'Hay và lãng mạn.','2025-08-05 09:06:09.000000',2,2),(3,7,'Rất đáng xem.','2025-08-05 09:06:09.000000',3,3),(4,9,'Kỹ xảo đỉnh cao.','2025-08-05 09:06:09.000000',NULL,4),(5,8,'Cười đau bụng.','2025-08-05 09:06:09.000000',NULL,5),(6,8,'Hay và rất lãng mạn .','2025-08-05 09:06:09.000000',NULL,6),(7,7,'Gay cấn!','2025-08-05 09:06:09.000000',NULL,7),(9,10,'Một tuyệt tác.','2025-08-05 09:06:09.000000',2,9),(10,9,'Diễn xuất tuyệt vời.','2025-08-05 09:06:09.000000',3,10),(11,5,'Amazing movie!','2025-08-06 14:36:47.097480',NULL,6),(15,5,'Amazing movie!','2025-08-06 14:44:14.702754',NULL,8),(16,5,'Amazing movie!','2025-08-06 14:44:20.377779',NULL,9),(21,3,'aafgege','2025-08-24 22:54:02.036278',1,41),(25,4,'','2025-10-21 15:29:02.293959',1,40),(26,3,'gdgd','2025-10-22 14:32:17.275952',1,42),(27,4,' bvhj','2025-10-22 15:24:10.386340',1,40);
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_648e3f5447f725579d7d4ffdfb` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ADMIN'),(3,'STAFF'),(2,'USER');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `refreshToken` varchar(255) DEFAULT NULL,
  `enabled` tinyint DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `activationCode` varchar(255) DEFAULT NULL,
  `avatar` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'tran hiep d17cnpm3','admin@gmail.com','$2b$10$MtovXcCXXAHgbWwIwnSvAO8rSwty0NDZpA90BDWdjntOgBxjn923O','2020-10-10 00:00:00','2025-10-10 00:00:00','$2b$10$yRHvUMbDhzsIX0e58gNFTebpJq4tKDTVJNr.bANjPMQwRUDwPrTQC',1,'male',NULL,'https://res.cloudinary.com/duhi7od89/image/upload/v1762065820/movies/bang-tn-1717476113116438976701-1762065701989.webp'),(2,'nguyen van a ','h1@gmail.com','$2b$10$MtovXcCXXAHgbWwIwnSvAO8rSwty0NDZpA90BDWdjntOgBxjn923O','2020-10-10 00:00:00','2025-10-10 00:00:00','$2b$10$BFzvGVjt0wW95cICMV7N4.lYJoUs2hSA96AruDIIERDjOngT49Exi',1,'female',NULL,NULL),(3,'tran thi b','h5@gmail.com','$2a$12$mRCHXs0B.Z/vhpKA78JuY.Q7C5fUCPgPRr6loztek9kMidTCex/aS','2025-07-24 22:19:17','2025-07-24 22:19:17','$2b$10$lhN/5d0dKtj.YrMPgn4pde2QNhyxa9UQB/CF59CrsHT0NNCVu8Rae',1,'male',NULL,'https://res.cloudinary.com/duhi7od89/image/upload/v1761225034/movies/%7B29C8B8B1-CD48-4EF5-89EA-6AB7D8F4C537%7D-1761224921739.png'),(49,'admin12@gmail.com','hiept6103@gmail.com','$2b$10$MtovXcCXXAHgbWwIwnSvAO8rSwty0NDZpA90BDWdjntOgBxjn923O','2025-10-31 15:33:33','2025-10-31 15:33:33','$2b$10$g2YWFTwTvNMfNnAH8X33begSDIDV5L3SPhRv1lkbyQJEgGWvY97pW',1,'M','c7fe9ac07ec4975fed3de5b5878a812d8ae57870',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `IDX_87b8888186ca9769c960e92687` (`user_id`),
  KEY `IDX_b23c65e50a758245a33ee35fda` (`role_id`),
  CONSTRAINT `FK_87b8888186ca9769c960e926870` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_b23c65e50a758245a33ee35fda1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1),(2,3),(3,3),(49,2);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-03 10:38:46
